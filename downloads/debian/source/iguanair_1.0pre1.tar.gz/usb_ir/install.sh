#!/bin/sh
# installer for iguanaIR
make install
