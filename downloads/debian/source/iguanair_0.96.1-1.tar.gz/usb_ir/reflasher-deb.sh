#!/bin/sh
dir=iguanair-reflasher

if [ -d $dir ]; then
	rm -r $dir
fi



if [ $# = 0 ]; then
	echo "First argument should be the iguanaIR-reflasher tar.bz2"

else

	if [ -s "$1" ]; then
		export DEBFULLNAME="IguanaWorks Incorporated"	
		echo "Making a deb packages from $1"
		mkdir $dir
		cp $1 $dir
		cd $dir
		tar -xjf $1
		cd iguanaIR-reflasher*
		dh_make -c gpl -e debsupport@iguanaworks.net -f ../$1 -p iguanair-reflasher -s
		cd ../..
		





	else 
		echo "Error: Cannot find iguanaIR-reflasher tar.gz2"
	fi
fi
