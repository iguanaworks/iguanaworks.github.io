# FindPy2Exe.py
#
try:
    import py2exe
    print("py2exe_version_str:%s" % py2exe.__version__)
except:
    pass
