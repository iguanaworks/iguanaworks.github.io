/* use the available clock_gettime */
#define USE_CLOCK_GETTIME 1
