Steps to build the installable Windows package:

1) Install the following in their default locations:
  A) Visual Studio Express
  B) cygwin for swig
  C) Python 2.6
  D) InnoSetup

2) Open the sln file.
3) Building the solution should generate the executable.
